# Import or bake a SuperCloud collector VM on a Windows Hyper-V host.
# Preferred entry point: copy Install-SuperCloudHyperVHost.ps1 next to this file
# and run that. This wrapper keeps the original -VhdPath calling convention.
param(
  [string]$VhdPath = "",
  [string]$Name = "SuperCloud-Collector",
  [string]$Switch = "External",
  [string]$Site = $(if ($env:SUPERCLOUD_SITE) { $env:SUPERCLOUD_SITE } else { "bkk" }),
  [string]$Token = $(if ($env:SUPERCLOUD_TOKEN) { $env:SUPERCLOUD_TOKEN } else { "" }),
  [string]$AppliancePath = ""
)
$ErrorActionPreference = "Stop"
$here = $PSScriptRoot
$hostScript = Join-Path $here "..\..\..\Install-SuperCloudHyperVHost.ps1"
if (-not (Test-Path $hostScript)) {
  $hostScript = Join-Path $here "Install-SuperCloudHyperVHost.ps1"
}
if (Test-Path $hostScript) {
  & $hostScript -VhdPath $VhdPath -VmName $Name -SwitchName $Switch -Site $Site -Token $Token -AppliancePath $AppliancePath
  return
}
if (-not $VhdPath) { throw "Pass -VhdPath or place Install-SuperCloudHyperVHost.ps1 beside this script." }
New-VM -Name $Name -MemoryStartupBytes 1GB -Generation 2 -VHDPath $VhdPath | Out-Null
Connect-VMNetworkAdapter -VMName $Name -SwitchName $Switch
Set-VMFirmware -VMName $Name -EnableSecureBoot Off
Start-VM $Name
Write-Host "$Name started. NIC is on $Switch and should take a DHCP lease."
