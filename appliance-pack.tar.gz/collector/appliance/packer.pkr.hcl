packer {
  required_plugins {
    qemu = {
      source  = "github.com/hashicorp/qemu"
      version = ">= 1.1.0"
    }
  }
}

variable "site" {
  type    = string
  default = env("SUPERCLOUD_SITE")
}

variable "token" {
  type      = string
  default   = env("SUPERCLOUD_TOKEN")
  sensitive = true
}

source "null" "docs" {
  communicator = "none"
}

build {
  name    = "supercloud-collector-pack"
  sources = ["source.null.docs"]
  provisioner "shell-local" {
    inline = [
      "mkdir -p dist",
      "cp cloud-init.yaml network-config.yaml Vagrantfile docker-compose.yml Dockerfile README.md firstboot.sh dist/",
      "printf 'site=%s\nmaster=https://supercloud.techmarkcompany.com\n' '${var.site}' > dist/appliance.env",
      "echo Built appliance pack in collector/appliance/dist"
    ]
  }
}
