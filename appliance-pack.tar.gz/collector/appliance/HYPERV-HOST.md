# SuperCloud collector on a Windows Hyper-V host

This host is a **site collector**. It must not hold the cloud console.
Do not `git clone` the SuperCloud repo onto it. Download only the collector
slice (`collector/` and `public/collector/`) from the master, or use
`git sparse-checkout` of those two paths.

Master console: https://supercloud.techmarkcompany.com  
Token: https://supercloud.techmarkcompany.com/collectors → Reveal token

## What “mount in Hyper-V” means here

| You have | What the script does |
|---|---|
| `.vhdx` / `.vhd` | Creates a VM and attaches that disk (`Add-VMHardDiskDrive` / `New-VM -VHDPath`). |
| `.iso` | Attaches it as the VM DVD. |
| collector pack `.tar.gz` | Extracts **collector files only**. Console `src/` is discarded if present. |
| nothing local | Downloads `$Master/collector/appliance-pack.tar.gz` (or the individual collector files). |

The guest **must** sit on an **External** switch. Internal / Default Switch cannot reach FortiGate `192.168.0.3` or the rest of `192.168.0.0/21`.

## Run on the Hyper-V host

Elevated PowerShell, host already on the site LAN. PowerShell only — no curl.

```powershell
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-ExecutionPolicy -Scope Process Bypass
Invoke-WebRequest -UseBasicParsing https://supercloud.techmarkcompany.com/collector/Install-SuperCloudHyperVHost.ps1 -OutFile $env:TEMP\Install-SuperCloudHyperVHost.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File $env:TEMP\Install-SuperCloudHyperVHost.ps1 -Site bkk -Token "PASTE-FROM-CONSOLE"
```

That pulls `https://supercloud.techmarkcompany.com/collector/appliance-pack.tar.gz` (collector section only). It does not clone the repo.

### Optional: git, collector paths only

```powershell
.\Install-SuperCloudHyperVHost.ps1 -GitSparse -Site bkk -Token "PASTE-FROM-CONSOLE"
```

That is `git clone --filter=blob:none --sparse --depth 1` plus
`git sparse-checkout set collector public/collector`. The console tree
(`src/`, the web app) is not checked out. If it appears, the script drops it.

Do **not** run `git clone https://github.com/TechmarkCo/SuperCloud.git` on this host.

### Host role only (no VM yet)

```powershell
.\Install-SuperCloudHyperVHost.ps1 -HostOnly -NetAdapterName "Ethernet"
```

Reboot if it exits `3010`, then run the same command again.

### You already built a VHDX (Packer / export)

```powershell
.\Install-SuperCloudHyperVHost.ps1 -VhdPath C:\VMs\supercloud-collector.vhdx -Site bkk -Token "..."
```

### Collector on the Hyper-V host itself (no guest)

Same LAN reach as a bridged VM. Needs Node.js LTS. Still no console tree.

```powershell
.\Install-SuperCloudHyperVHost.ps1 -NativeHost -HostOnly -Site bkk -Token "..."
```

## First-boot contract (do not change)

1. NIC0 = DHCP on the site LAN.
2. Outbound HTTPS to `https://supercloud.techmarkcompany.com`.
3. Token + site id in cloud-init / `/etc/supercloud.env` / `/etc/bastion/collector.config.json`.
4. Inventory stays on the box at `/etc/bastion/inventory.yaml` (`chmod 600`).
5. The agent at `/opt/bastion/bastion-collector.mjs` replaces itself on upgrade.

Do not cron a second copy. Do not put device passwords in the console URL.
A test job is not required. Do not shut a port to prove the path.

## After it starts

```powershell
Get-VM SuperCloud-Collector
Get-VMNetworkAdapter -VMName SuperCloud-Collector
VMConnect localhost SuperCloud-Collector
```

Sites on the master console should show the collector live within about a minute.

## Manual equivalent (if you refuse the script)

```powershell
Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -All
# reboot
$nic = (Get-NetAdapter | ? Status -eq Up | ? Virtual -ne $true)[0].Name
New-VMSwitch -Name SuperCloud-External -NetAdapterName $nic -AllowManagementOS $true
New-VM -Name SuperCloud-Collector -MemoryStartupBytes 1GB -Generation 1 -VHDPath .\disk.vhd -SwitchName SuperCloud-External
Set-VMDvdDrive -VMName SuperCloud-Collector -Path .\cidata.iso
Start-VM SuperCloud-Collector
```

Generation 1 is used with Canonical’s Azure VHD. A Gen2 VHDX from Packer should
use `-Generation 2` and `MicrosoftUEFICertificateAuthority` Secure Boot (the
script does that when you pass a `.vhdx`).

## What “mount in Hyper-V” means here

| You have | What the script does |
|---|---|
| `.vhdx` / `.vhd` | Creates a VM and attaches that disk (`Add-VMHardDiskDrive` / `New-VM -VHDPath`). |
| `.iso` | Attaches it as the VM DVD. |
| `.ova` or the `.tar.gz` pack | Extracts it. If there is no disk inside, downloads the Ubuntu Azure VHD and builds a `CIDATA` seed ISO from `collector/appliance/cloud-init.yaml`. |
| You only want to inspect a VHDX on the host | `.\Install-SuperCloudHyperVHost.ps1 -MountVhdOnly -VhdPath .\disk.vhdx` (`Mount-VHD`). Linux ext4 will not get a Windows letter. |

The guest **must** sit on an **External** switch. Internal / Default Switch cannot reach FortiGate `192.168.0.3` or the rest of `192.168.0.0/21`.

## Run on the Hyper-V host

Elevated PowerShell, host already on the site LAN:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Install-SuperCloudHyperVHost.ps1 -Site bkk -Token "PASTE-FROM-CONSOLE"
```

The script uses only PowerShell (`Invoke-WebRequest`). Do not install curl.exe.
It looks next to itself for `supercloud-collector-appliance.tar.gz` or
`supercloud-collector-pack`. Override with `-AppliancePath`.

### Host role only (no VM yet)

```powershell
.\Install-SuperCloudHyperVHost.ps1 -HostOnly -NetAdapterName "Ethernet"
```

Reboot if it exits `3010`, then run the same command again.

### You already built a VHDX (Packer / export)

```powershell
.\Install-SuperCloudHyperVHost.ps1 -VhdPath C:\VMs\supercloud-collector.vhdx -Site bkk -Token "..."
```

### Collector on the Hyper-V host itself (no guest)

Same LAN reach as a bridged VM. Needs Node.js LTS.

```powershell
.\Install-SuperCloudHyperVHost.ps1 -NativeHost -HostOnly -Site bkk -Token "..."
```

## First-boot contract (do not change)

1. NIC0 = DHCP on the site LAN.
2. Outbound HTTPS to `https://supercloud.techmarkcompany.com`.
3. Token + site id in cloud-init / `/etc/supercloud.env` / `/etc/bastion/collector.config.json`.
4. Inventory stays on the box at `/etc/bastion/inventory.yaml` (`chmod 600`).
5. The agent at `/opt/bastion/bastion-collector.mjs` replaces itself on upgrade.

Do not cron a second copy. Do not put device passwords in the console URL.
A test job is not required. Do not shut a port to prove the path.

## After it starts

```powershell
Get-VM SuperCloud-Collector
Get-VMNetworkAdapter -VMName SuperCloud-Collector
VMConnect localhost SuperCloud-Collector
```

Sites on the master console should show the collector live within about a minute.

## Manual equivalent (if you refuse the script)

```powershell
Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -All
# reboot
$nic = (Get-NetAdapter | ? Status -eq Up | ? Virtual -ne $true)[0].Name
New-VMSwitch -Name SuperCloud-External -NetAdapterName $nic -AllowManagementOS $true
New-VM -Name SuperCloud-Collector -MemoryStartupBytes 1GB -Generation 1 -VHDPath .\disk.vhd -SwitchName SuperCloud-External
Set-VMDvdDrive -VMName SuperCloud-Collector -Path .\cidata.iso
Start-VM SuperCloud-Collector
```

Generation 1 is used with Canonical’s Azure VHD. A Gen2 VHDX from Packer should
use `-Generation 2` and `MicrosoftUEFICertificateAuthority` Secure Boot (the
script does that when you pass a `.vhdx`).
