# SuperCloud site collector appliance

All-in-one on-site collector. One box per site. It uses DHCP, reaches the
firewall / switches / endpoints / servers on the LAN, and takes configuration
from the master console:

https://supercloud.techmarkcompany.com

The collector upgrades itself from that console.

A full multi-gigabyte OVA is not stored in git. This folder is the pack you
import. Build an OVA when you need a downloadable VM image.

## Fastest path (no VM build)

On any Linux host that already has DHCP:

```
curl -fsSL https://supercloud.techmarkcompany.com/collector/install.sh \
  | sudo sh -s -- --site SITEID --token TOKEN
```

Windows (Admin PowerShell — no curl):

```
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-RestMethod https://supercloud.techmarkcompany.com/collector/install.ps1 | Invoke-Expression
```

Or save then run:

```
Invoke-WebRequest -UseBasicParsing https://supercloud.techmarkcompany.com/collector/install.ps1 -OutFile $env:TEMP\sc-install.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File $env:TEMP\sc-install.ps1 -Site SITEID -Token TOKEN
```

Pass `-Site` and `-Token` if they are not already in the environment.

## Docker (host network, DHCP is the host NIC)

```
cd collector/appliance
export SUPERCLOUD_SITE=bkk SUPERCLOUD_TOKEN=...
docker compose up -d
```

`network_mode: host` is required so the collector can see the LAN and bind
honeypot ports.

## Vagrant VM (DHCP)

```
cd collector/appliance
export SUPERCLOUD_SITE=bkk SUPERCLOUD_TOKEN=...
vagrant up
```

The box gets an address from the site DHCP server (`bridged` NIC).

## Packer OVA / QCOW2

```
cd collector/appliance
packer init .
SUPERCLOUD_SITE=bkk SUPERCLOUD_TOKEN=... packer build packer.pkr.hcl
```

Output lands in `collector/appliance/dist/`. Import the OVA into Hyper-V,
VMware, Proxmox or VirtualBox. First NIC must be the site LAN (DHCP).

## Hyper-V host (Windows)

The site Hyper-V host must **not** clone the SuperCloud repo (that tree is the
cloud console). Download the collector slice only.

Elevated PowerShell:

```
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -UseBasicParsing https://supercloud.techmarkcompany.com/collector/Install-SuperCloudHyperVHost.ps1 -OutFile $env:TEMP\Install-SuperCloudHyperVHost.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File $env:TEMP\Install-SuperCloudHyperVHost.ps1 -Site SITEID -Token TOKEN
```

The script then downloads `$Master/collector/appliance-pack.tar.gz`
(`collector/` + `public/collector/` only). Optional git path:

```
.\Install-SuperCloudHyperVHost.ps1 -GitSparse -Site SITEID -Token TOKEN
```

that sparse-checkouts `collector` and `public/collector` — never `src/`.
See `HYPERV-HOST.md`.

## First boot contract

1. NIC0 = DHCP on the site LAN.
2. Outbound HTTPS to `https://supercloud.techmarkcompany.com`.
3. Token and site id from cloud-init / env / `/etc/bastion/collector.config.json`.
4. Inventory (IPs and device logins) stays on the box in `/etc/bastion/inventory.yaml`.
5. Agent file `/opt/bastion/bastion-collector.mjs` is replaced on upgrade.

Do not put device passwords in the cloud console URL.
