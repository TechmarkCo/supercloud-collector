#!/bin/sh
# Install the SuperCloud collector from a cloned repo. For internet-only hosts use:
#   curl -fsSL https://supercloud.techmarkcompany.com/collector/install.sh | sudo sh -s -- --site SITE --token TOKEN
set -e
ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
install -d /opt/bastion /etc/bastion
install -m 755 "$ROOT/public/collector/bastion-collector.mjs" /opt/bastion/bastion-collector.mjs
install -m 755 "$ROOT/public/collector/start-collector.sh" /opt/bastion/start-collector.sh
if [ -f "$ROOT/collector/site/bkk.inventory.yaml" ] && [ ! -f /etc/bastion/inventory.yaml ]; then
  install -m 600 "$ROOT/collector/site/bkk.inventory.yaml" /etc/bastion/inventory.yaml
fi
if [ ! -f /etc/bastion/collector.config.json ]; then
  cat > /etc/bastion/collector.config.json << 'EOF'
{
  "siteId": "bkk",
  "hostname": "COLLECTOR-BKK",
  "hubUrl": "https://supercloud.techmarkcompany.com/collector/v1",
  "token": "PASTE-FROM-SUPERCLOUD-SITES",
  "inventoryPath": "/etc/bastion/inventory.yaml",
  "pollSeconds": 20,
  "autoUpgrade": true,
  "honeypot": {
    "enabled": true,
    "bind": "0.0.0.0",
    "services": [
      { "name": "SSH", "port": 2222, "banner": "SSH-2.0-OpenSSH_8.4" },
      { "name": "HTTP", "port": 8088 },
      { "name": "SMB", "port": 4450 }
    ]
  }
}
EOF
  chmod 600 /etc/bastion/collector.config.json
fi
install -m 644 "$ROOT/collector/install/bastion-collector.service" /etc/systemd/system/bastion-collector.service
systemctl daemon-reload
if grep -q PASTE-FROM-SUPERCLOUD-SITES /etc/bastion/collector.config.json; then
  echo "Token missing. Open https://supercloud.techmarkcompany.com/collectors, reveal the token, edit /etc/bastion/collector.config.json, then: systemctl enable --now bastion-collector"
  exit 0
fi
systemctl enable --now bastion-collector
systemctl --no-pager status bastion-collector
