# Install the SuperCloud collector from a cloned repo. Run as Administrator.
# Internet-only: irm https://supercloud.techmarkcompany.com/collector/install.ps1 | iex
$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$Dest = "C:\Bastion"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item (Join-Path $Root "public\collector\bastion-collector.mjs") (Join-Path $Dest "bastion-collector.mjs") -Force
Copy-Item (Join-Path $Root "public\collector\start-collector.ps1") (Join-Path $Dest "start-collector.ps1") -Force
$invSrc = Join-Path $Root "collector\site\bkk.inventory.yaml"
if ((Test-Path $invSrc) -and -not (Test-Path (Join-Path $Dest "inventory.yaml"))) {
  Copy-Item $invSrc (Join-Path $Dest "inventory.yaml")
}

$config = Join-Path $Dest "collector.config.json"
if (-not (Test-Path $config)) {
  @'
{
  "siteId": "bkk",
  "hostname": "COLLECTOR-BKK",
  "hubUrl": "https://supercloud.techmarkcompany.com/collector/v1",
  "token": "PASTE-FROM-SUPERCLOUD-SITES",
  "inventoryPath": "C:\\Bastion\\inventory.yaml",
  "pollSeconds": 20,
  "autoUpgrade": true,
  "honeypot": {
    "enabled": true,
    "bind": "0.0.0.0",
    "services": [
      { "name": "SSH", "port": 2222, "banner": "SSH-2.0-OpenSSH_8.4" },
      { "name": "HTTP", "port": 8088 },
      { "name": "SMB", "port": 4450 }
    ]
  }
}
'@ | Set-Content -Path $config -Encoding ascii
}

$tr = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Bastion\start-collector.ps1"
schtasks /Create /TN BastionCollector /SC ONSTART /RL HIGHEST /F /TR $tr | Out-Null
if (Select-String -Path $config -Pattern "PASTE-FROM-SUPERCLOUD-SITES" -Quiet) {
  Write-Host "Token missing. Open https://supercloud.techmarkcompany.com/collectors, reveal the token, edit C:\Bastion\collector.config.json, then start task BastionCollector."
  exit 0
}
schtasks /Run /TN BastionCollector
