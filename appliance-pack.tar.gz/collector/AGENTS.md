# SuperCloud site collector

The entry point is [GROK-HANDOFF.md](../GROK-HANDOFF.md). Read that first if you have not.

Install `public/collector/bastion-collector.mjs` (1.2.0) with
`collector/install/install-linux.sh`, `collector/install/install-windows.ps1`,
or the internet bootstrap:

```
curl -fsSL https://supercloud.techmarkcompany.com/collector/install.sh | sudo sh -s -- --site SITE --token TOKEN
```

The master console is https://supercloud.techmarkcompany.com. Collectors pull
config from `/collector/v1/config` and upgrade themselves from
`/collector/v1/version`.

## Layout

Linux:

```
/opt/bastion/bastion-collector.mjs
/etc/bastion/inventory.yaml
/etc/bastion/collector.config.json
```

Windows:

```
C:\Bastion\bastion-collector.mjs
C:\Bastion\inventory.yaml
C:\Bastion\collector.config.json
```

`hubUrl` must be `https://supercloud.techmarkcompany.com/collector/v1` unless
the operator points at a lab console.

## Device families

Use `family` in the inventory. Do not send Cisco IOS to every switch.

| family | How to act |
|---|---|
| `fortigate` | SSH or HTTPS API. Quarantine with `diagnose user quarantine add src4 <ip> 86400`. |
| `fortianalyzer` | Read-only. |
| `cisco-sb` | Small Business CLI. Shut the access port only. |
| `unifi` | Prefer the UniFi controller. Do not guess empty passwords. |
| `mikrotik-swos` | HTTP only. |
| `unknown` | Try SSH then HTTPS. Report if both refuse. |

Port shutdown is last resort after Webroot cleanup / isolate and FortiGate
quarantine. Never shut an uplink.

## Appliance

See [collector/appliance/README.md](appliance/README.md). DHCP on NIC0.
The pack lives in git; bake an OVA with Packer when a downloadable VM is needed.

Never print passwords, the Webroot secret, or the hub token.
